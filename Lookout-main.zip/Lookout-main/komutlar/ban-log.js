const Discord = require('discord.js')
const db = require('croxydb')
exports.run = async(client, message, args ) => {

  if (!message.member.hasPermission("MANAGER")) return message.channel.send('**\`Gerekli Yetkin Yok Dostum\`**')

let k = message.mentions.channels.first()

if (!k) return message.channel.send(`Kanal Belirt!`)
  
  
  
  db.set(`banlog_${message.guild.id}`, k.id)
  
  const sa = new Discord.MessageEmbed()
  .setDescription(`Ban Log **${k}** Olarak Ayarlandı`)
  return message.channel.send(sa)
};
exports.conf = {
  aliases: [],
  permLevel: 0
};
exports.help = {
  name: 'ban-log'
}; 