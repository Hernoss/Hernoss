const Discord = require("discord.js");

exports.run = (client, message, args) => {
  const rexus = new Discord.MessageEmbed()
    .setColor("#00ee00")
    .setDescription("**<a:ok:825446442558685224> Bot Sahibi = <@724568715047206973> **\n** <a:ok:825446442558685224> Geliştirci = <@749678134877618207> ** ")
    .setFooter("Papaz#9999")
  message.channel.send(rexus);
};

exports.conf = {
  enabled: true,
  guildOnly: false,
  aliases: [],
  permLevel: 0
};

exports.help = {
  name: "yapımcım",
  description: "",
  usage: ""
};