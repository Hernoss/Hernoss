const Discord = require("discord.js");

exports.run = async (client, message, args) => {

const yardım = new Discord.MessageEmbed()
.setColor("RANDOM")
.setTitle("Lookout Yardım Menüsü V12 Sürümle")
.setDescription("** Moderasyon Komutlar Açarsın \`_moderasyon\` **\n** Guard Komutlar Açarsın \`_guard\` **\n** Kulanıcı Komutları Açarsın \`_Kulancı-bilgi\` **  ")
.addField(`Lookout Davet Baglantısı `, ` [Bot Davet Linki](https://discord.com/api/oauth2/authorize?client_id=827458186398138419&permissions=8&scope=bot) **|** [Destek Sunucusu](https://discord.gg/CPJkxZc8tu) `)

.setFooter(`${message.author.username} Tarafından İstendi`, message.author.avatarURL)
.setImage("https://cdn.discordapp.com/attachments/760029308214312960/827470333639655464/standard.gif")
message.channel.send(yardım)

}

exports.conf = {
  enabled: true, 
  guildOnly: false, 
   aliases: ["help","k"],
  permLevel: `Yetki gerekmiyor.` 
};

exports.help = {
  name: 'yardım',
  category: 'kullanıcı',
  description: 'Yardım Menüsü.',
   usage:'yardım'
}











