const Discord = require("discord.js");

exports.run = async (client, message, args) => {

const yardım = new Discord.MessageEmbed()
.setColor("RANDOM")
.setDescription("\n \n ════════════════\`Lookout Guard\`════════════════ \n \n ** Sunucuda Küfür Engel kapat/aç \`_küfür-ayarla\` **\n** Sunucuda Relam Engel kapat/aç \`_reklam-engelle\`**  ")

.setFooter(`${message.author.username} Tarafından İstendi`, message.author.avatarURL)
.setImage("https://cdn.discordapp.com/attachments/760029308214312960/827470333639655464/standard.gif")
message.channel.send(yardım)

}

exports.conf = {
  enabled: true, 
  guildOnly: false, 
   aliases: ["help","k"],
  permLevel: `Yetki gerekmiyor.` 
};

exports.help = {
  name: 'guard',
  category: 'kullanıcı',
  description: 'Yardım Menüsü.',
   usage:'guard'
}











