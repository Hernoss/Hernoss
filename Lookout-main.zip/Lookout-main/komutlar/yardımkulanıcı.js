const Discord = require("discord.js");

exports.run = async (client, message, args) => {

const yardım = new Discord.MessageEmbed()
.setColor("RANDOM")
.setDescription("\n \n ════════════════\`Lookout Moderasyon\`════════════════ \n \n ** Botun Yapımcısı Görürsün \`_yapımcım\` **\n** Kulanıcı Bilgini Görürsün \`_profil\` **\n** Sunucu Avatar Büyütürsün \`_avatar\` **  ")

.setFooter(`${message.author.username} Tarafından İstendi`, message.author.avatarURL)
.setImage("https://cdn.discordapp.com/attachments/760029308214312960/827470333639655464/standard.gif")
message.channel.send(yardım)

}

exports.conf = {
  enabled: true, 
  guildOnly: false, 
   aliases: ["help","k"],
  permLevel: `Yetki gerekmiyor.` 
};

exports.help = {
  name: 'Kulancı-bilgi',
  category: 'kullanıcı',
  description: 'Yardım Menüsü.',
   usage:'Kulancı-bilgi'
}











