const Discord = require("discord.js");

exports.run = async (client, message, args) => {

const yardım = new Discord.MessageEmbed()
.setColor("RANDOM")
.setDescription("\n \n ════════════════\`Lookout Moderayon\`════════════════ \n \n ** Otorol Sunucu Açarsın @üye #kanal \`_otorol ayarla`\ **\n** Sunucuda Mesajları Siler \`_sil\`**\n** Sunucudan Birini Banlarsın \`_ban\` **\n** Sunucuda Etiketlediniz Kanala Ban log Açar \`_ban-log\` **\n** Ban Limit Açarsın \`_banlimit\` **\n** Sunucuda Sohbet Klitler \`_sohbet-kapat\` **\n** Sunucuda Kanalı Kilitler \`_sohbet-kapat\` **\n** Sunucuda Banlana Kişini id Bunu Yapiştırın Ban Kalkar \`_unban\` **\n** Sunucuda Yetkilirini Görürsün \`_yetkilerim\` **\n**  Sunucuda Mesajları Siler \`_sil\`**  ")

.setFooter(`${message.author.username} Tarafından İstendi`, message.author.avatarURL)
.setImage("https://cdn.discordapp.com/attachments/760029308214312960/827470333639655464/standard.gif")
message.channel.send(yardım)

}

exports.conf = {
  enabled: true, 
  guildOnly: false, 
   aliases: ["help","k"],
  permLevel: `Yetki gerekmiyor.` 
};

exports.help = {
  name: 'moderasyon',
  category: 'kullanıcı',
  description: 'Yardım Menüsü.',
   usage:'`moderasyon'
}











